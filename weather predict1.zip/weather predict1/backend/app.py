"""
=====================================================
WEATHER FEEL PREDICTOR
Weather Classification using Machine Learning
=====================================================
"""

from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import json
import os
from datetime import datetime
from collections import Counter

# ============================================================
# DATA LAYER
# ============================================================

class WeatherData:
    """Weather classification training data"""
    
    # Training data with temperature and feel labels
    TRAINING_DATA = {
        10: "very cold",
        15: "cold",
        20: "pleasant",
        25: "comfortable",
        30: "warm",
        35: "hot",
        40: "very hot"
    }
    
    EXTENDED_DATA = {
        -10: "extremely freezing",
        -5: "bitterly cold",
        0: "freezing",
        5: "very cold",
        10: "cold",
        15: "cool",
        20: "pleasant",
        22: "nice",
        25: "comfortable",
        28: "mildly warm",
        30: "warm",
        33: "quite warm",
        35: "hot",
        38: "very hot",
        40: "extremely hot",
        45: "scorching"
    }
    
    DESCRIPTIONS = {
        "extremely freezing": "Dangerously cold! Stay indoors! 🥶",
        "bitterly cold": "Bitter cold! Bundle up! ❄️",
        "freezing": "Freezing temperatures! Wear heavy winter gear! ⛄",
        "very cold": "Very cold! Layer up with warm clothes! 🧤",
        "cold": "Cold weather! Jacket and scarf recommended! 🧣",
        "cool": "Cool! Light jacket might be needed! 🌥️",
        "pleasant": "Pleasant weather! Perfect for outdoor activities! 😊",
        "nice": "Nice conditions! Enjoy your day! 🌤️",
        "comfortable": "Very comfortable! Ideal weather! 🌞",
        "mildly warm": "Getting warm! Light clothing recommended! 👕",
        "warm": "Warm! T-shirt and shorts weather! 🩳",
        "quite warm": "Quite warm! Stay hydrated! 💧",
        "hot": "Hot! Use sunscreen and seek shade! 🕶️",
        "very hot": "Very hot! Stay cool with AC! ❄️",
        "extremely hot": "Extremely hot! Avoid outdoor activities! 🔥",
        "scorching": "Scorching heat! Stay indoors with AC! 🏠"
    }
    
    @classmethod
    def get_label_description(cls, label):
        return cls.DESCRIPTIONS.get(label, "Enjoy your day! 🌈")

# ============================================================
# ML ALGORITHM ENGINE
# ============================================================

class WeatherPredictor:
    """Weather Prediction using Nearest Neighbor Algorithm"""
    
    def __init__(self):
        self.data = WeatherData.EXTENDED_DATA
        self.temperatures = sorted(self.data.keys())
        self.min_temp = min(self.temperatures)
        self.max_temp = max(self.temperatures)
        self.history_file = "data/history.json"
        self.prediction_history = []
        self.load_history()
    
    def predict(self, temp):
        """
        Nearest Neighbor Algorithm:
        1. Calculate distance from input to each training point
        2. Find the training point with minimum distance
        3. Return the label of that point
        """
        if temp < self.min_temp:
            nearest_temp = self.min_temp
            label = self.data[nearest_temp]
            distance = abs(temp - nearest_temp)
        elif temp > self.max_temp:
            nearest_temp = self.max_temp
            label = self.data[nearest_temp]
            distance = abs(temp - nearest_temp)
        else:
            nearest_temp = min(self.temperatures, key=lambda x: abs(x - temp))
            label = self.data[nearest_temp]
            distance = abs(temp - nearest_temp)
        
        # Calculate confidence (inverse of distance)
        max_distance = (self.max_temp - self.min_temp) / 2
        confidence = max(0, min(100, (1 - distance / max_distance) * 100))
        
        return {
            "temperature": round(temp, 1),
            "label": label,
            "nearest_temp": nearest_temp,
            "distance": round(distance, 1),
            "confidence": round(confidence, 1),
            "description": WeatherData.get_label_description(label)
        }
    
    def predict_knn(self, temp, k=3):
        """K-Nearest Neighbors Algorithm"""
        if k > len(self.temperatures):
            k = len(self.temperatures)
        
        neighbors = sorted(self.temperatures, key=lambda x: abs(x - temp))[:k]
        neighbor_labels = [self.data[t] for t in neighbors]
        
        label_counts = Counter(neighbor_labels)
        most_common_label = label_counts.most_common(1)[0][0]
        votes = label_counts[most_common_label]
        
        return {
            "temperature": round(temp, 1),
            "label": most_common_label,
            "k": k,
            "neighbors": neighbors,
            "neighbor_labels": neighbor_labels,
            "votes": votes,
            "total_neighbors": k,
            "confidence": round((votes / k) * 100, 1)
        }
    
    def add_prediction(self, temp, label, method="NN"):
        """Store prediction in history"""
        entry = {
            "timestamp": datetime.now().isoformat(),
            "temperature": temp,
            "label": label,
            "method": method
        }
        self.prediction_history.append(entry)
        self.save_history()
        return entry
    
    def get_statistics(self):
        """Get prediction statistics"""
        if not self.prediction_history:
            return {"total_predictions": 0}
        
        labels = [h["label"] for h in self.prediction_history]
        label_counts = Counter(labels)
        
        return {
            "total_predictions": len(self.prediction_history),
            "unique_labels": len(label_counts),
            "label_distribution": dict(label_counts),
            "most_common": label_counts.most_common(1)[0] if label_counts else None
        }
    
    def save_history(self):
        """Save history to JSON file"""
        os.makedirs(os.path.dirname(self.history_file), exist_ok=True)
        with open(self.history_file, 'w') as f:
            json.dump(self.prediction_history, f, indent=2)
    
    def load_history(self):
        """Load history from JSON file"""
        if os.path.exists(self.history_file):
            with open(self.history_file, 'r') as f:
                self.prediction_history = json.load(f)
            return True
        return False

# ============================================================
# FLASK API - BACKEND
# ============================================================

app = Flask(__name__,
            static_folder='../frontend',
            static_url_path='')
CORS(app)

# Initialize predictor
predictor = WeatherPredictor()

# ============================================================
# API ENDPOINTS
# ============================================================

@app.route('/')
def index():
    """Serve the frontend HTML"""
    return app.send_static_file('index.html')

@app.route('/api/predict', methods=['POST'])
def predict():
    """Predict weather feel for a given temperature"""
    try:
        data = request.get_json()
        temp = float(data.get('temperature'))
        
        result = predictor.predict(temp)
        predictor.add_prediction(temp, result['label'], "NN")
        
        return jsonify({
            "success": True,
            "prediction": result,
            "message": f"Temperature {temp}°C feels {result['label']}"
        })
    
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 400

@app.route('/api/predict-knn', methods=['POST'])
def predict_knn():
    """K-Nearest Neighbors prediction"""
    try:
        data = request.get_json()
        temp = float(data.get('temperature'))
        k = int(data.get('k', 3))
        
        result = predictor.predict_knn(temp, k)
        predictor.add_prediction(temp, result['label'], f"KNN-{k}")
        
        return jsonify({
            "success": True,
            "prediction": result,
            "message": f"KNN Prediction: {temp}°C feels {result['label']}"
        })
    
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 400

@app.route('/api/batch-predict', methods=['POST'])
def batch_predict():
    """Batch prediction for multiple temperatures"""
    try:
        data = request.get_json()
        temps = data.get('temperatures', [])
        
        results = []
        for temp in temps:
            result = predictor.predict(float(temp))
            results.append(result)
            predictor.add_prediction(float(temp), result['label'], "Batch")
        
        return jsonify({
            "success": True,
            "predictions": results,
            "count": len(results)
        })
    
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 400

@app.route('/api/statistics', methods=['GET'])
def get_statistics():
    """Get prediction statistics"""
    try:
        stats = predictor.get_statistics()
        return jsonify({
            "success": True,
            "statistics": stats
        })
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 400

@app.route('/api/history', methods=['GET'])
def get_history():
    """Get prediction history"""
    try:
        return jsonify({
            "success": True,
            "history": predictor.prediction_history[-20:],
            "total": len(predictor.prediction_history)
        })
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 400

@app.route('/api/clear-history', methods=['DELETE'])
def clear_history():
    """Clear prediction history"""
    try:
        predictor.prediction_history = []
        predictor.save_history()
        return jsonify({
            "success": True,
            "message": "History cleared successfully"
        })
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 400

@app.route('/api/training-data', methods=['GET'])
def get_training_data():
    """Get training data"""
    try:
        return jsonify({
            "success": True,
            "data": predictor.data
        })
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 400

# ============================================================
# RUN THE APPLICATION
# ============================================================

if __name__ == '__main__':
    print("=" * 60)
    print("🌤️  WEATHER FEEL PREDICTOR")
    print("=" * 60)
    print(f"📊 Training data points: {len(predictor.data)}")
    print(f"🌡️  Temperature range: {predictor.min_temp}°C to {predictor.max_temp}°C")
    print(f"📈 History records: {len(predictor.prediction_history)}")
    print("=" * 60)
    print("\n🚀 Server running at: http://localhost:5000")
    print("=" * 60)
    
    app.run(debug=True, port=5000)