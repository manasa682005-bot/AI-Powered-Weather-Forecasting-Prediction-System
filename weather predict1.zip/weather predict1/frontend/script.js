/**
 * =====================================================
 * WEATHER FEEL PREDICTOR - FRONTEND APPLICATION
 * =====================================================
 */

// API Base URL
const API_URL = 'http://localhost:5000';

// ============================================================
// DOM ELEMENTS
// ============================================================

const elements = {
    temperature: document.getElementById('temperature'),
    predictBtn: document.getElementById('predict-btn'),
    predictKnnBtn: document.getElementById('predict-knn-btn'),
    result: document.getElementById('result'),
    resultEmoji: document.getElementById('result-emoji'),
    resultLabel: document.getElementById('result-label'),
    resultTemp: document.getElementById('result-temp'),
    resultConfidence: document.getElementById('result-confidence'),
    resultDescription: document.getElementById('result-description'),
    
    batchTemps: document.getElementById('batch-temps'),
    batchBtn: document.getElementById('batch-btn'),
    batchResults: document.getElementById('batch-results'),
    
    totalPredictions: document.getElementById('total-predictions'),
    uniqueLabels: document.getElementById('unique-labels'),
    mostCommon: document.getElementById('most-common'),
    refreshStatsBtn: document.getElementById('refresh-stats-btn'),
    
    historyList: document.getElementById('history-list'),
    clearHistoryBtn: document.getElementById('clear-history-btn'),
    
    trainingData: document.getElementById('training-data'),
};

// ============================================================
// EMOJI MAP
// ============================================================

function getWeatherEmoji(temp) {
    if (temp <= -5) return '🥶';
    if (temp <= 0) return '❄️';
    if (temp <= 10) return '☃️';
    if (temp <= 15) return '🌥️';
    if (temp <= 20) return '⛅';
    if (temp <= 25) return '☀️';
    if (temp <= 30) return '🌤️';
    if (temp <= 35) return '🌡️';
    if (temp <= 40) return '🔥';
    return '🌋';
}

// ============================================================
// PREDICTION FUNCTIONS
// ============================================================

async function predictTemperature() {
    const temp = elements.temperature.value;
    
    if (!temp) {
        alert('Please enter a temperature!');
        return;
    }
    
    try {
        const response = await fetch(`${API_URL}/api/predict`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ temperature: parseFloat(temp) })
        });
        
        const data = await response.json();
        
        if (data.success) {
            displayResult(data.prediction);
            loadHistory();
            loadStatistics();
        } else {
            alert('Error: ' + data.error);
        }
    } catch (error) {
        alert('Network Error: Make sure the backend is running!');
        console.error('Error:', error);
    }
}

async function predictKNN() {
    const temp = elements.temperature.value;
    
    if (!temp) {
        alert('Please enter a temperature!');
        return;
    }
    
    const k = prompt('Enter number of neighbors (K):', '3');
    if (k === null) return;
    
    try {
        const response = await fetch(`${API_URL}/api/predict-knn`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                temperature: parseFloat(temp),
                k: parseInt(k) || 3
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            displayResult(data.prediction);
            loadHistory();
            loadStatistics();
        } else {
            alert('Error: ' + data.error);
        }
    } catch (error) {
        alert('Network Error: Make sure the backend is running!');
        console.error('Error:', error);
    }
}

function displayResult(prediction) {
    const emoji = getWeatherEmoji(prediction.temperature);
    
    elements.resultEmoji.textContent = emoji;
    elements.resultLabel.textContent = prediction.label.toUpperCase();
    elements.resultTemp.textContent = `${prediction.temperature.toFixed(1)}°C`;
    elements.resultConfidence.textContent = `Confidence: ${prediction.confidence}%`;
    elements.resultDescription.textContent = prediction.description || 'Enjoy your day! 🌈';
    
    elements.result.classList.remove('hidden');
    
    elements.result.style.animation = 'none';
    setTimeout(() => {
        elements.result.style.animation = 'slideIn 0.5s ease';
    }, 10);
}

// ============================================================
// BATCH PREDICTION
// ============================================================

async function batchPredict() {
    const tempsInput = elements.batchTemps.value;
    
    if (!tempsInput) {
        alert('Please enter temperatures!');
        return;
    }
    
    const temps = tempsInput.split(',').map(t => parseFloat(t.trim()));
    
    if (temps.some(isNaN)) {
        alert('Please enter valid numbers!');
        return;
    }
    
    try {
        const response = await fetch(`${API_URL}/api/batch-predict`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ temperatures: temps })
        });
        
        const data = await response.json();
        
        if (data.success) {
            displayBatchResults(data.predictions);
            loadHistory();
            loadStatistics();
        } else {
            alert('Error: ' + data.error);
        }
    } catch (error) {
        alert('Network Error: Make sure the backend is running!');
        console.error('Error:', error);
    }
}

function displayBatchResults(predictions) {
    let html = '<div class="batch-grid">';
    
    predictions.forEach(pred => {
        const emoji = getWeatherEmoji(pred.temperature);
        html += `
            <div class="batch-item">
                <div class="temp">${pred.temperature.toFixed(1)}°C</div>
                <div class="emoji">${emoji}</div>
                <div class="label">${pred.label}</div>
            </div>
        `;
    });
    
    html += '</div>';
    elements.batchResults.innerHTML = html;
}

// ============================================================
// STATISTICS
// ============================================================

async function loadStatistics() {
    try {
        const response = await fetch(`${API_URL}/api/statistics`);
        const data = await response.json();
        
        if (data.success) {
            const stats = data.statistics;
            elements.totalPredictions.textContent = stats.total_predictions || 0;
            elements.uniqueLabels.textContent = stats.unique_labels || 0;
            
            if (stats.most_common) {
                elements.mostCommon.textContent = `${stats.most_common[0]} (${stats.most_common[1]})`;
            } else {
                elements.mostCommon.textContent = 'N/A';
            }
        }
    } catch (error) {
        console.error('Error loading statistics:', error);
    }
}

// ============================================================
// HISTORY
// ============================================================

async function loadHistory() {
    try {
        const response = await fetch(`${API_URL}/api/history`);
        const data = await response.json();
        
        if (data.success && data.history.length > 0) {
            let html = '';
            data.history.slice().reverse().forEach(item => {
                const emoji = getWeatherEmoji(item.temperature);
                const time = new Date(item.timestamp).toLocaleTimeString();
                html += `
                    <div class="history-item">
                        <span class="temp">${item.temperature}°C ${emoji}</span>
                        <span class="label">${item.label}</span>
                        <span class="time">${time}</span>
                    </div>
                `;
            });
            elements.historyList.innerHTML = html;
        } else {
            elements.historyList.innerHTML = '<p class="empty-message">No predictions yet. Start predicting!</p>';
        }
    } catch (error) {
        console.error('Error loading history:', error);
    }
}

async function clearHistory() {
    if (!confirm('Are you sure you want to clear all prediction history?')) {
        return;
    }
    
    try {
        const response = await fetch(`${API_URL}/api/clear-history`, {
            method: 'DELETE'
        });
        
        const data = await response.json();
        
        if (data.success) {
            loadHistory();
            loadStatistics();
            alert('History cleared successfully!');
        } else {
            alert('Error: ' + data.error);
        }
    } catch (error) {
        alert('Network Error: Make sure the backend is running!');
        console.error('Error:', error);
    }
}

// ============================================================
// TRAINING DATA
// ============================================================

async function loadTrainingData() {
    try {
        const response = await fetch(`${API_URL}/api/training-data`);
        const data = await response.json();
        
        if (data.success) {
            let html = '<div class="training-grid">';
            const trainingData = data.data;
            
            Object.entries(trainingData).forEach(([temp, label]) => {
                const emoji = getWeatherEmoji(parseFloat(temp));
                html += `
                    <div class="training-item">
                        <div class="temp">${temp}°C ${emoji}</div>
                        <div class="label">${label}</div>
                    </div>
                `;
            });
            
            html += '</div>';
            elements.trainingData.innerHTML = html;
        }
    } catch (error) {
        elements.trainingData.innerHTML = '<p class="empty-message">Could not load training data</p>';
        console.error('Error loading training data:', error);
    }
}

// ============================================================
// EVENT LISTENERS
// ============================================================

elements.predictBtn.addEventListener('click', predictTemperature);
elements.predictKnnBtn.addEventListener('click', predictKNN);
elements.batchBtn.addEventListener('click', batchPredict);
elements.refreshStatsBtn.addEventListener('click', loadStatistics);
elements.clearHistoryBtn.addEventListener('click', clearHistory);

elements.temperature.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') predictTemperature();
});

elements.batchTemps.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') batchPredict();
});

// ============================================================
// INITIALIZATION
// ============================================================

async function init() {
    console.log('🌤️ Weather Predictor Starting...');
    await loadStatistics();
    await loadHistory();
    await loadTrainingData();
    console.log('✅ Application Ready!');
}

init();

setInterval(() => {
    loadStatistics();
    loadHistory();
}, 30000);

console.log('🚀 Weather Predictor Loaded!');